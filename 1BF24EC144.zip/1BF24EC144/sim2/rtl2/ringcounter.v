
`timescale 1ns/1ps

// 4-bit Ring Counter
// Sequence: 0001 -> 0010 -> 0100 -> 1000 -> 0001
// Asynchronous active-high reset

module ring_counter #(parameter N = 4) (
    input clk,
    input rst,
    output reg [N-1:0] q
);

    always @(posedge clk or posedge rst) begin
        if (rst)
            q <= {{(N-1){1'b0}}, 1'b1};
        else
            q <= {q[N-2:0], q[N-1]};
    end

endmodule
