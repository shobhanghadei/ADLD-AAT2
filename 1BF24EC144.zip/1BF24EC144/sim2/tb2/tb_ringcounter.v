`timescale 1ns/1ps

// Self-checking testbench for 4-bit ring counter
// Expected final PASS message:
// RING COUNTER TB : PASSED

module tb;

    reg clk;
    reg rst;
    wire [3:0] q;

    reg [3:0] expected;
    integer i;
    integer errors;

    // Instantiate the design under test
    ring_counter #(.N(4)) uut (
        .clk(clk),
        .rst(rst),
        .q(q)
    );

    // Clock period = 10 ns
    initial clk = 1'b0;
    always #5 clk = ~clk;

    // Check the counter after each rising edge
    task check_next_state;
        begin
            @(posedge clk);
            #1;

            expected = {expected[2:0], expected[3]};

            if (q !== expected) begin
                errors = errors + 1;
                $display(
                    "FAIL at %0t: q=%b, expected=%b",
                    $time, q, expected
                );
            end

            // Verify that exactly one bit is HIGH
            if ((q == 4'b0000) ||
                ((q & (q - 4'b0001)) != 4'b0000)) begin
                errors = errors + 1;
                $display(
                    "FAIL at %0t: output is not one-hot, q=%b",
                    $time, q
                );
            end

            $display("%4t ns : q = %b", $time, q);
        end
    endtask

    initial begin
        errors = 0;
        expected = 4'b0001;
        rst = 1'b0;

        $dumpfile("dump.vcd");
        $dumpvars(0, tb);

        // Apply asynchronous reset
        #2 rst = 1'b1;
        #2;

        if (q !== 4'b0001) begin
            errors = errors + 1;
            $display("FAIL: reset value q=%b", q);
        end
        else begin
            $display("%4t ns : q = %b (RESET)", $time, q);
        end

        // Release reset between clock edges
        #3 rst = 1'b0;

        // Test three complete rotations
        for (i = 0; i < 12; i = i + 1)
            check_next_state;

        // Assert asynchronous reset between clock edges
        #2 rst = 1'b1;
        #1;

        if (q !== 4'b0001) begin
            errors = errors + 1;
            $display("FAIL: asynchronous reset q=%b", q);
        end
        else begin
            $display("%4t ns : q = %b (ASYNC RESET)", $time, q);
        end

        // Release reset and restart the expected sequence
        #2 rst = 1'b0;
        expected = 4'b0001;

        // Verify six additional clock transitions
        for (i = 0; i < 6; i = i + 1)
            check_next_state;

        // Final test result
        if (errors == 0)
            $display("RING COUNTER TB : PASSED");
        else
            $display("RING COUNTER TB : FAILED (%0d errors)", errors);

        $finish;
    end

endmodule

