1793263749 /home/student/cadWorkDir/myProjects/Digital/1BF24EC144/sim/rtl/comparator_4bit.v
1793263904 /home/student/cadWorkDir/myProjects/Digital/1BF24EC144/sim/tb/tb_comparator_4bit.v
