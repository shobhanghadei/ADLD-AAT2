1793255663 /home/student/cds.lib
1793263749 /home/student/cadWorkDir/myProjects/Digital/1BF24EC144/sim/rtl/comparator_4bit.v
