`timescale 1ns/1ps
// 4-bit cascadable magnitude comparator (stand-alone use: gt_in = 0, eq_in = 1, lt_in = 0)
module comparator_4bit(
    input  [3:0] a, b,
    input        gt_in, eq_in, lt_in,
    output       gt, eq, lt
);
    wire [3:0] x    = ~(a ^ b);
    wire       eq_w = &x;
    wire       gt_w = (a[3] & ~b[3])
                    | (x[3] & a[2] & ~b[2])
                    | (x[3] & x[2] & a[1] & ~b[1])
                    | (x[3] & x[2] & x[1] & a[0] & ~b[0]);
    wire       lt_w = (~a[3] & b[3])
                    | (x[3] & ~a[2] & b[2])
                    | (x[3] & x[2] & ~a[1] & b[1])
                    | (x[3] & x[2] & x[1] & ~a[0] & b[0]);

    assign gt = gt_w | (eq_w & gt_in);
    assign eq = eq_w & eq_in;
    assign lt = lt_w | (eq_w & lt_in);
endmodule
